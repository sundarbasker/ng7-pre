import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../environments/environment';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { catchError } from 'rxjs/internal/operators/catchError';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  // getNumberDetails(finalUrl): Observable<any>{

  // }
  constructor(private http: HttpClient) { }

getUsers():Observable<any>{
 // return this.http.get('https://reqres.in/api/users')
 return this.http.get(environment.usersURL)
 .pipe(
   map(result => result),
  //catchError(this.handleError)
 );
}

  firstClick(){
    return console.log('clicked');
  }
}
